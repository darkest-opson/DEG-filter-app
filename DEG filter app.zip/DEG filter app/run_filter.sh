#!/bin/bash
pip install -r requirements.txt
streamlit run filterDEGs.py

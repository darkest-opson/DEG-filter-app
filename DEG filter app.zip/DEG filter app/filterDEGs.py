import streamlit as st
import pandas as pd
import os
from io import BytesIO
from PIL import Image

def filter_degs(df, adj_p_value_threshold, log2fc_threshold):
    """
    Filters a DataFrame based on adj_p_value and log2FC thresholds.

    Parameters:
        df (pd.DataFrame): DataFrame to filter.
        adj_p_value_threshold (float): Threshold for adjusted p-value.
        log2fc_threshold (float): Threshold for log2 fold change (absolute value).

    Returns:
        pd.DataFrame: Filtered DataFrame.
    """
    return df[
        (df['P-adj'] < adj_p_value_threshold) &
        (abs(df['log2(FC)']) >= log2fc_threshold)
    ]

def main():
    st.title("DEG File Filter App")
    st.write("Upload CSV, TSV, or Excel files to filter DEGs based on adjusted p-value and log2FC thresholds.")
    st.write("Make sure the columns given in the image should be present along with Same header name")

    image = Image.open('./img.png')
    st.image(image)
    # Sidebar for thresholds
    st.sidebar.header("Filter Settings")
    adj_p_value_threshold = st.sidebar.number_input(
        "Adjusted p-value threshold", min_value=0.0, max_value=1.0, value=0.05, step=0.01
    )
    log2fc_threshold = st.sidebar.number_input(
        "Log2 Fold Change (absolute) threshold", min_value=0.0, value=1.0, step=0.1
    )

    # Upload multiple files
    uploaded_files = st.file_uploader(
        "Upload DEG files (CSV, TSV, or Excel)", type=['csv', 'tsv', 'tabular', 'xlsx', 'xls'], accept_multiple_files=True
    )
    i = 1
    if uploaded_files:
        # Process each uploaded file
        for uploaded_file in uploaded_files:
            st.write(f"Uploaded file : {uploaded_file.name}")
            file_extension = os.path.splitext(uploaded_file.name)[-1].lower()

            # Read the uploaded file
            try:
                if file_extension == ".csv":
                    df = pd.read_csv(uploaded_file)
                elif file_extension in [".tsv", ".tabular"]:
                    df = pd.read_csv(uploaded_file, sep="\t")
                elif file_extension in [".xls", ".xlsx"]:
                    df = pd.read_excel(uploaded_file)
                else:
                    st.warning(f"Unsupported file format: {uploaded_file.name}")
                    continue
            except Exception as e:
                st.error(f"Error reading file {uploaded_file.name}: {e}")
                continue

            # Filter the data
            try:
                filtered_df = filter_degs(df, adj_p_value_threshold, log2fc_threshold)
                st.header(f"{i}. Filtered results for **{uploaded_file.name}**:")
                positive = filtered_df[filtered_df["log2(FC)"]>0]
                negative = filtered_df[filtered_df["log2(FC)"]<=0]

                if st.button(f'Click to watch processed the data for {uploaded_file.name}'):  
                    st.dataframe(filtered_df)
                    st.write(f"Upregulated data:")
                    st.dataframe(positive)
                    st.write(f"Downregulated data:")
                    st.dataframe(negative)

               
                # Save DataFrames to an Excel file with multiple sheets
                output = BytesIO()
                output_file_name = f"filtered_results_{uploaded_file.name}.xlsx"

                with pd.ExcelWriter(output, engine='xlsxwriter') as writer:
                    filtered_df.to_excel(writer, sheet_name="Filtered Results", index=False)
                    positive.to_excel(writer, sheet_name="Positive Data", index=False)
                    negative.to_excel(writer, sheet_name="Negative Data", index=False)

                # Reset BytesIO pointer for Streamlit download
                output.seek(0)

                # Create Streamlit download button
                st.download_button(
                    label=f"Download {output_file_name}",
                    data=output.getvalue(),
                    file_name=output_file_name,
                    mime="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
                )
                st.header("****"*10)
                i+=1
            except Exception as e:
                st.error(f"Error processing file {uploaded_file.name}: {e}")

if __name__ == "__main__":
    main()
